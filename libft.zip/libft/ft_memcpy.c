/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/10 15:21:43 by numussan          #+#    #+#             */
/*   Updated: 2021/12/26 18:17:51 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	char	*temp_dst;
	char	*temp_src;

	if (!dst && !src)
		return (NULL);
	temp_dst = (char *)dst;
	temp_src = (char *)src;
	while (n--)
		*temp_dst++ = *temp_src++;
	return ((void *)dst);
}

// int	main(void)
// {
// 	char src[10] = "123456789";
// 	char dst[10] = "abu dhabi";
// 	printf("%s\n%s\n\n", src, dst);
// 	ft_memcpy(dst, src, 5);
// 	printf("%s\n%s\n", src, dst);
// 	return (0);
// }