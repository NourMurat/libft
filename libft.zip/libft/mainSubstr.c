#include "libft.h"

int	main(void)
{
	const char	str[] = "Ilon Musk";
	const int	start = 2;
	size_t	len = 48;

	printf("%s\n", str);
	char *res = ft_substr(str, start, len);
	printf("%s\n", res);
	return (0);
}
 