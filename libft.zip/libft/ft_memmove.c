/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/10 18:27:14 by numussan          #+#    #+#             */
/*   Updated: 2021/12/15 04:06:00 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dst, const void *src, size_t len)
{
	const unsigned char	*temp_src;
	unsigned char		*temp_dst;

	temp_src = src;
	temp_dst = dst;
	if (!dst || !src)
		return (NULL);
	if (dst < src)
	{
		while (len--)
			*temp_dst++ = *temp_src++;
	}
	else
	{
		while (len--)
			*(temp_dst + len) = *(temp_src + len);
	}
	return (dst);
}

// int		main(void)
// {
// 	unsigned char src[] = "1234567890";
// 	printf("%s\n", src);
// 	ft_memmove(src + 1, src + 4, 6);
// 	printf("%s\n", src);
// 	return (0);
// }