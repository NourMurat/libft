/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/06 17:22:31 by numussan          #+#    #+#             */
/*   Updated: 2021/12/15 03:56:47 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_bzero(void *s, size_t n)
{
	char	*ch;

	ch = s;
	while (n--)
		*ch++ = 0;
}

// int	main(void)
// {
// 	char str[11] = "JavaScript";

// 	printf("%s\n", str);
// 	ft_bzero(str, 5);
// 	printf("%s\n", str+6);
// 	return (0);
// }