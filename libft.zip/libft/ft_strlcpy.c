/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/15 14:56:49 by numussan          #+#    #+#             */
/*   Updated: 2021/12/26 17:16:20 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcpy(char *dst, const char *src, size_t dstsize)
{
	size_t	i;

	i = 0;
	if (dstsize)
	{
		while ((src[i]) && --dstsize)
		{
			dst[i] = src[i];
			i++;
		}
		dst[i] = '\0';
	}
	return (ft_strlen(src));
}

// int		main(void)
// {
// 	char *str = "Javascript";
// 	char buf[10] = "\0";

// 	printf("String - \"%s\"\n", str);
// 	printf("Bufer - \"%s\", size - |%zu|\n\n", buf, sizeof(buf));

// 	size_t sizeBufAfter = ft_strlcpy(buf, str, sizeof(buf));
// 	printf("Bufer after strlcpy - \"%s\", size - |%zu|\n", buf, sizeBufAfter);
// 	return (0);
// }