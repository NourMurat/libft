#include <stdio.h>
#include <string.h>

//char	*ft_strnstr(const char *haystack, const char *needle, size_t len);


int		main(void)
{
	const char haystack[] = "Good morning!!!";
//	const char needle[] = "mo";
	size_t len = 9;
	char *func = strnstr(haystack, NULL, len);
	printf("%s\n", func);
	return (0);
}
