#include <stdlib.h>
#include <stdio.h>

//void	*ft_calloc(size count, size_t size);

int		main(void)
{
	printf("%s\n", calloc(2, sizeof(char)));
	return (0);
}

