/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/30 12:00:04 by numussan          #+#    #+#             */
/*   Updated: 2021/12/21 18:22:14 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(const char *s, unsigned int start, size_t len)
{
	char	*temp_s;
	char	*result;

	temp_s = (char *)s;
	if (start > ft_strlen(temp_s) - 1)
		return (0);
	if (len + start > ft_strlen(temp_s))
	{
		result = (char *)malloc((ft_strlen(temp_s) - start + 1) * sizeof(char));
		ft_strlcpy(result, temp_s + start, ft_strlen(temp_s) - start + 1);
	}
	else
	{
		result = (char *)malloc((len + 1) * sizeof(char));
		ft_strlcpy(result, temp_s + start, len + 1);
		return (result);
	}
	if (!result)
		return (NULL);
	return (result);
}

// int	main(void)
// {
// 	const char	str[] = "12345678901234567890";

// 	printf("%s\n", str);
// 	char *res = ft_substr(str, 19, 20);
// 	printf("%s\n", res);
// 	return (0);
// }