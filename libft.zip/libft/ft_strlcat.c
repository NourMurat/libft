/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/21 22:01:18 by numussan          #+#    #+#             */
/*   Updated: 2021/12/26 18:09:46 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t dstsize)
{
	size_t	len;

	len = ft_strnlen(dst, dstsize);
	if (len == dstsize)
		return (len + ft_strlen(src));
	return (len + ft_strlcpy(dst + len, src, dstsize - len));
}

// int	main(void)
// {
// 	char src[] = "abcdefjhig";
// 	char dst[] = "1234567890";
// 	printf("dst len - %zu\n\n", ft_strlen(dst));
// 	size_t length = strlcat(dst, src, 11);
// 	printf("result length - %lu\n", length);
// 	printf("src -> %s\ndst - > %s\n", src, dst);
// 	return (0);  
// }