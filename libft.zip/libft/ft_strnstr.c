/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/27 16:54:26 by numussan          #+#    #+#             */
/*   Updated: 2021/12/23 16:13:57 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

int	check_needle(char *str, char *to_find)
{
	int	i;

	i = 0;
	while (to_find[i])
	{
		if (str[i] != to_find[i])
			return (0);
		i++;
	}
	return (1);
}

char	*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	char	*temp_haystack;
	char	*temp_needle;

	temp_haystack = (char *)haystack;
	temp_needle = (char *)needle;
	if (*needle == '\0')
		return (temp_haystack);
	while (*temp_haystack++ && len--)
	{
		while (*temp_haystack == *temp_needle)
		{
			if (check_needle(temp_haystack, temp_needle))
				return (temp_haystack);
			temp_needle++;
		}
	}
	return (NULL);
}
