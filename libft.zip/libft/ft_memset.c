/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/06 15:59:55 by numussan          #+#    #+#             */
/*   Updated: 2021/12/20 01:00:43 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *b, int c, size_t len)
{
	char	*ch;

	ch = b;
	while (len--)
		*ch++ = (unsigned char) c;
	return (b);
}

// int		main(void)
// {
//     char str[] = "JavaScript";
//     printf("%s\n", str);
//     printf("%s\n", ft_memset(str, 'S', 3));
//     return (0);
// }