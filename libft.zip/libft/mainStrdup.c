#include <stdio.h>
#include <string.h>

char *ft_strdup(const char *s1);

int		main(void)
{
	const char s1[] = "Hello 42!";
	char *dup = ft_strdup(s1);
	printf("Duplicate - %s\n", dup);
	return (0);
}
