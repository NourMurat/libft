# include "libft.h"

int main(void)
{
    const char *s1;
	s1 = "Hello ";
    const char *s2;
	s2 = "42!!!";

    char *res = ft_strjoin(s1, s2);
    printf("%s\n", res);
    return (0);
}
