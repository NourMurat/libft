/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/12 01:05:18 by numussan          #+#    #+#             */
/*   Updated: 2021/12/15 02:25:49 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strtrim(char const	*s1, char const	*set)
{
	char	*res;
	int		i;
	int		k;
	int		len;
	int		start;

	i = 0;
	k = 0;
	len = 0;
	while (s1[i++])
	{
		while (set[k] && s1[i] == set[k])
			k++;
	}
	start = i;
	k = 0;
	while (s1[i++])
	{
		while (set[k] && s1[i] != set[k])
			k++;
		len++;
	}
	res = ft_substr(s1, start, len);
	return (res);
}

// int		main(void)
// {
// 	char const	s1[] = "   123  abc   456   ";
// 	char const set[] = "123456    ";
// 	char *res;
// 	res = ft_strtrim(s1, set);
// 	printf("%s\n", res);
// 	return 0;
// }