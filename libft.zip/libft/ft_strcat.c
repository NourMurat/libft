#include "libft.h"

char	*ft_strcat(char *s1, const char *s2)
{
	char	*temp_s2;
	size_t	i;
	size_t	size;

	temp_s2 = (char *)s2;
	size = ft_strlen(s1);
	i = 0;
	while (s2)
		s1[size++] = s2[i++];
	s1[size] = '\0';
	return (s1);
}

int	main(void){
	char s1[] = "Good ";
	const char s2[] = "morning!!!";
	char *concat;

	concat = ft_strcat(s1, s2);
	printf("%s\n%s\n\n%s\n", s1, s2, concat);
	return (0);
}
