/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: numussan <numussan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/26 23:59:50 by numussan          #+#    #+#             */
/*   Updated: 2021/12/26 21:22:40 by numussan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// char	*ft_strrchr(const char *s, int c)
// {
// 	int		i;
// 	char	ch;

// 	i = 0;
// 	ch = (char)c;
// 	while (s[i++])
// 		;
// 	while (i >= 0)
// 	{
// 		if (s[i] == ch)
// 			return ((char *)(s + i));
// 		i--;
// 	}
// 	return (NULL);
// }
char	*ft_strrchr(const char *s, int c)
{
	char	*result;
	char	ch;

	result = (char *)0;
	ch = (char)*s;
	while (*s)
	{
		if (ch == c)
			result = (char *)s;
		s++;
	}
	return (result);
}
// int	main(void)
// {
// 	const char	s[] = "tripouille!";
// 	char	*res = ft_strrchr(s, 'i');
// 	printf("%s\n", res);
// 	return 0;
// }