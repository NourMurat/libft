#include <stdio.h>
#include <stdlib.h>

int		ft_atoi(const char *str);

int		main(void)
{
	printf("%d\n", ft_atoi("      -2147483647"));
	return (0);
}
